<!DOCTYPE html>
<html>
<head>
	<title>
		Welcome To The Book Fort
	</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	
<style type="text/css">
	nav
	{
		float: right;
		word-spacing: 30px;
		padding: 20px;
	}
	nav li 
	{
		display: inline-block;
		line-height: 80px;
	}
</style>
</head>


<body>
	<div class="wrapper">
		<header>
		<div class="logo">
			<img src="images/9.png">
			<h1 style="color: white;">Book Fort</h1>
		</div>
			<nav>
				<ul>
					<li><a href="index.php">HOME</a></li>
					<li><a href="index1.php">BOOKS</a></li>
					<li><a href="user_login.php">USER-LOGIN</a></li>
					<li><a href="admin_login.php">ADMIN-LOGIN</a></li>
					<li><a href="registration.php">REGISTRATION</a></li>
					<li><a href="feedback.php">FEEDBACK</a></li>
				</ul>
			</nav>
		</header>
		<section>
			<div class="sec_img">
				 <marquee behavior="scroll" direction="left" scrollamount="13">
    <img src="images/g.jpg" width="500" height="250" alt="Natural" />
    <img src="images/F.jpg" width="500" height="250" alt="Natural" />
    <img src="images/D.jpg" width="500" height="250" alt="Natural" />
    <img src="images/E.jpg" width="500" height="250" alt="Natural" />
     <img src="images/15.jpg" width="500" height="250" alt="Natural" />
    <img src="images/10.jpg" width="500" height="250" alt="Natural" />
    <img src="images/11.jpg" width="500" height="250" alt="Natural" />
    <img src="images/12.jpg" width="500" height="250" alt="Natural" />
    <img src="images/13.jpg" width="500" height="250" alt="Natural" />
    <img src="images/14.jpg" width="500" height="250" alt="Natural" />
    <img src="images/16.jpg" width="500" height="250" alt="Natural" />
  </marquee>

			<br><br><br>
			<div class="box">
				<br><br><br><br>
				<marquee behavior="scroll" direction="left" scrollamount="8">	
<h1 style="text-align: center; font-size: 35px;color:yellow;">Welcome to the world of books</h1>
                 </marquee>
				<br><br>
				<h1 style="text-align: center;font-size: 25px;color:violet;">Register first to enter the world  </h1><br>
				
			</div>
		</div>
		</section>
		<footer>
			<p style="color:white;  text-align: center; ">
				<br><br>
				Email:&nbsp Online.library@gmail.com <br>
				Mobile:&nbsp +88018********
			</p>
		</footer>
	</div>
</body>

</html>