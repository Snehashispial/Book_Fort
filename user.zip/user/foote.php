<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
	<link rel="stylesheet" type="text/css" href="style.css">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<style type="text/css">

</style>
</head>
<body>

	<p style="color:white;  text-align: center; ">
				<br><br>
				Email:&nbsp Online.library@gmail.com <br>
				Mobile:&nbsp +88018********
			</p>

</body>
</html>