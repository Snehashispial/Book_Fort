<?php
  include "header1.php";
  ?>
 
 <div class="container" >
    <div class="row" style="margin-right: 80px">
      <div class="col-lg-2">

      </div>
      <div class= "col-lg-10">
        <div class="alert alert-success" style="background-color: #34ce57; color: white; text-align: center;">
          <h5 style= "font-size: 35px;"> Welcome to Admin Panel</h5>

        </div>
        <div class= "card-deck">
        <div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/addbook.png" alt="Card image cap" height="200">
  <div class="card-body">
    <h4 class="card-title text-primary"></h4>
    <a href="add_books.php" class="btn btn-success" style="width: 100%;">ADD BOOKS</a>
  </div>
</div>

<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/delbook.png" alt="Card image cap" height="200">
  <div class="card-body">
    <h4 class="card-title text-primary"></h4>
    <a href="view_books.php" class="btn btn-success" style="width: 100%;">VIEW BOOKS</a>
  </div>
</div>

<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/viewbook.png" alt="Card image cap" height="200">
  <div class="card-body">
    <h4 class="card-title text-primary"></h4>
    <a href="delete_books.php" class="btn btn-success" style="width: 100%;">Remove Books</a>
  </div>
</div>

        

</div>
        </div>
      </div>
    </div>