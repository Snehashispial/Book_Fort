<?php

   $db=mysqli_connect("localhost", "root", "", "book_fort" );  /*server name, username, password, database name */

   ?>