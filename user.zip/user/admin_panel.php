 <?php
  include "header1.php";
  ?>
 <div class="container" >
    <div class="row" style="margin-right: 80px">
      <div class="col-lg-2">

      </div>
      <div class= "col-lg-10">
        <div class="alert alert-success" style="background-color: #34ce57; color: white; text-align: center;">
          <h5 style= "font-size: 35px;"> Welcome to Admin Panel</h5>

        </div>
        <div class= "card-deck">
        <div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/users.png" alt="Card image cap" height="200">
  <div class="card-body">
    <h4 class="card-title text-primary">Registered Users</h4>
    <a href="registered_users.php" class="btn btn-success" style="width: 100%;">View Users</a>
  </div>
</div>

<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/books.png" alt="Card image cap" height="200">
  <div class="card-body">
    <h4 class="card-title text-primary">Manage Books</h4>
    <a href="managebooks.php" class="btn btn-success" style="width: 100%;">View and Manage Books</a>
  </div>
</div>

<div class="card" style="width: 18rem;">
  <img class="card-img-top" src="images/order.png" alt="Card image cap" height="200">
  <div class="card-body">
    <h4 class="card-title text-primary">Orders History</h4>
    <a href="orders.php" class="btn btn-success" style="width: 100%;">View History</a>
  </div>
</div>

        

</div>
        </div>
      </div>
    </div>

     