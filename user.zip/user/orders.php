<?php
  include "header1.php";
  ?>
 <div class="container" >
    <div class="row" style="margin-right: 80px">
      <div class="col-lg-2">

      </div>
      <div class= "col-lg-10">

          <form class="form-inline">
    <input class="form-control mr-sm-2" type="search" placeholder="Enter Username" aria-label="Search">
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button> &nbsp;&nbsp;
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">View All</button>
  </form>
  
        </div>
      </div>
    </div>