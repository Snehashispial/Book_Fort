<html>
   <head>
     <title>Submit Button Redirect</title>
   </head>    
    <body>     
     <form method="POST" action="myPage.php">
       <input type="submit"/>
     </form>    
    </body>    
</html>